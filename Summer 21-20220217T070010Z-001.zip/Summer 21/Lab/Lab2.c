#include<stdio.h>
#include<unistd.h>

int main()
{
	pid_t id = fork();
	if(id == 0)
	{
		for(int i = 1; i <= 100; i++)
		{
			if(i % 3 == 0 && i % 2 == 0)
			{
				printf("%d\n",i);
			}
		}
		printf("\n");
	}
	else
	{
		for(int i = 1; i <= 100; i++)
		{
			if(i % 3 == 0 && i % 2 != 0)
			{
				printf("%d\n",i);
			}
		}
		printf("\n");
	}
	return 0;
}